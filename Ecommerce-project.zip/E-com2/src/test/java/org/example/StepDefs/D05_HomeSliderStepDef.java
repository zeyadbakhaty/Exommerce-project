package org.example.StepDefs;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.example.pages.P03_HomePage;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import java.time.Duration;

public class D05_HomeSliderStepDef {
    P03_HomePage homePage = new P03_HomePage();
@When("user click on first slider")
    public void userClickOnFirstSlider (){
    homePage.slider1.click();
    }
    @Then("user go to slider 1 product page")
    public void userGoToSlider1ProductPage (){
        WebDriverWait wait =new WebDriverWait(Hooks.driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.urlToBe("https://demo.nopcommerce.com/Galaxy-S22-Ultra"));
        String ExpectedURL = "https://demo.nopcommerce.com/Galaxy-S22-Ultra";
        String ActualURL = Hooks.driver.getCurrentUrl();
        Assert.assertEquals(ActualURL,ExpectedURL);

    }
    @When("user click on second slider")
    public void userClickOnSecondSlider (){
    homePage.sliderControl.click();
    homePage.slider2.click();
    }
    @Then("user go to slider 2 product page")
    public void userGoToSlider2ProductPage (){
        WebDriverWait wait =new WebDriverWait(Hooks.driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.urlToBe("https://demo.nopcommerce.com/iphone-14Pro"));
        String ExpectedURL = "https://demo.nopcommerce.com/iphone-14Pro";
        String ActualURL = Hooks.driver.getCurrentUrl();
        Assert.assertEquals(ActualURL,ExpectedURL);




    }

}
