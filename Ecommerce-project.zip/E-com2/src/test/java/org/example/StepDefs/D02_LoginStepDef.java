package org.example.StepDefs;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.example.pages.P02_Login;
import org.openqa.selenium.support.Color;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

public class D02_LoginStepDef {
    P02_Login loginPage = new P02_Login();
    SoftAssert softAssert = new SoftAssert();

    @Given("user go to login page")
    public void Login (){
        loginPage.Loginbtn.click();
    }
    @When("user enter email {string} and password {string}")
    public void userEnterEmailAndPassword(String email , String password) {

        loginPage.Email.sendKeys(email);
        loginPage.password.sendKeys(password);
    }

    @And("user press login")
    public void userPressLogin() {
        loginPage.loginBtn.click();
    }
    @Then("user Login successfully")
   public void successLogin () throws InterruptedException{
    String ExpectedURL = "https://demo.nopcommerce.com/";
    String ActualURL = Hooks.driver.getCurrentUrl();
    softAssert.assertEquals(ActualURL,ExpectedURL);
    softAssert.assertAll();
    }
    
    @Then("Error message appear")
    public void errorMessageAppear() {
    String ExpectedMessage = "Login was unsuccessful. Please correct the errors and try again.";
    String ActualMessage = loginPage.ErrorMessage.getText();
    softAssert.assertTrue (ActualMessage.contains(ExpectedMessage)); ;
    String ExpectedColor = "#e4434b";
    String ActualColor =  Color.fromString(loginPage.ErrorMessage.getCssValue("color")).asHex();;
    softAssert.assertEquals(ActualColor,ExpectedColor);
    softAssert.assertAll();

    }
}
